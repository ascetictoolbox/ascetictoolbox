#!/bin/bash
SCM3_IP=109.231.67.130
echo "$SCM3_IP  kms.optimis.eu">> /etc/hosts

/var/lib/securecloud/scconfig.sh --csp-id=Native --ignore-ssl-error --guid=5F671159-2801-4559-9F1B-F1DA8CBC51AB --url=https://kms.optimis.eu:8443/ --passphrase=qqQQ11\!\! --register --publish-inventory --with-provisioning --timeout=3 -k
