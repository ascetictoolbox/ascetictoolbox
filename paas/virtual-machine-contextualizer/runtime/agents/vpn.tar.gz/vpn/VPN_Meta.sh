#!/bin/bash
/opt/optimis/vpn/install_CAClient.sh > /opt/optimis/vpn/install.log 2>&1
sleep 3
/opt/optimis/vpn/deploy_CAClient.sh > /opt/optimis/vpn/vpn.log 2>&1
sleep 5
/opt/optimis/vpn/install_Peer.sh > /opt/optimis/vpn/install.log 2>&1
sleep 3
/opt/optimis/vpn/deploy_Peer.sh >> /opt/optimis/vpn/vpn.log 2>&1 &
