#!/bin/bash
rpm -ev ds_agent-9.0.0-883.x86_64
