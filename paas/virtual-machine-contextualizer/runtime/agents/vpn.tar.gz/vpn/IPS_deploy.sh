#!/bin/bash
/opt/ds_agent/dsa_control -a "dsm://109.231.67.132:4120/" >> /opt/optimis/vpn/dsa.log 2>&1
