#!/bin/bash
/opt/optimis/vpn/deps_KMS.sh
/opt/optimis/vpn/conf_KMS.sh
/opt/optimis/vpn/deploy_KMS.sh
