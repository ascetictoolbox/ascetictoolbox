#!/usr/bin/expect -f
spawn /var/lib/securecloud/scconfig.sh -h
expect "More"
send "q"
sleep 1
expect "(yes/no)?"
sleep 1
send "yes\r"
interact
