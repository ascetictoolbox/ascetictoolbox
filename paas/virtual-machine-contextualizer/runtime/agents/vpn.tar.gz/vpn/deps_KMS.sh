#!/bin/bash
yum install expect expectk -y
