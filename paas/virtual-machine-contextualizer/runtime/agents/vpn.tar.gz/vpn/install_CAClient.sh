#!/bin/bash
tar xzvf /opt/optimis/vpn/BrokerVPNCredentials.tar.gz -C /opt/optimis/vpn/
