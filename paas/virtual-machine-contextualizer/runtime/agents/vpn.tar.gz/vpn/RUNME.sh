#!/bin/bash
#
# This script will be executed *after* all the other init scripts.
# You can put your own initialization stuff in here if you don't
# want to do the full Sys V style init stuff.

touch /var/lock/subsys/local
source /etc/profile

mkdir -p /opt/optimis/
tar zxvf /mnt/context/agents/vpn.tar.gz -C /opt/optimis/
chmod -R 777 /opt/optimis/vpn

#Install and start the agents

#IPS
/bin/date > /opt/optimis/vpn/dsa.log
/opt/optimis/vpn/IPS_Meta.sh

#VPN
/opt/optimis/vpn/VPN_Meta.sh

#KMS
/bin/date > /opt/optimis/vpn/kms.log
/opt/optimis/vpn/KMS_Meta.sh
