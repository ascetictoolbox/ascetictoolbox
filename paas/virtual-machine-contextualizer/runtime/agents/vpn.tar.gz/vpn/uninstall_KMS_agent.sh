#!/bin/bash
rpm -ev scagent-1.2.0.1062-1.el6.x86_64
