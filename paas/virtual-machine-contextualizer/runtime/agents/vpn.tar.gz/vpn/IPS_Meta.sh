#!/bin/bash
/opt/optimis/vpn/IPS_deploy.sh >> /opt/optimis/vpn/dsa.log 2>&1 &
