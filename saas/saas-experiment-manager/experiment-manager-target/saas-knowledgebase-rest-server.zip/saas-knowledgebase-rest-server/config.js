
exports.db_url = 'mongodb://ascetic-integration.int.cetic.be:27017/saasknowledgebase';
