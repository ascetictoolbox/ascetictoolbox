'use strict';

exports.experimentsGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "deployments" : [ {
    "deplId" : "aeiou",
    "components" : [ {
      "name" : "aeiou",
      "description" : "aeiou",
      "_id" : "aeiou",
      "type" : "aeiou"
    } ],
    "name" : "aeiou",
    "_id" : "aeiou"
  } ],
  "application" : "aeiou",
  "appId" : "aeiou",
  "name" : "aeiou",
  "description" : "aeiou",
  "_id" : "aeiou",
  "kpis" : [ {
    "unit" : "aeiou",
    "level" : "aeiou",
    "metric" : {
      "submetric" : "",
      "unit" : "aeiou",
      "kpi" : "aeiou",
      "name" : "aeiou",
      "description" : "aeiou",
      "_id" : "aeiou",
      "type" : "aeiou",
      "properties" : {
        "key" : "aeiou"
      }
    },
    "name" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou"
  } ],
  "events" : [ {
    "name" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou"
  } ]
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.experimentsPost = function(args, res, next) {
  /**
   * parameters expected in the args:
   * body (Experiment)
   **/

var examples = {};
  
  examples['application/json'] = {
  "deployments" : [ {
    "deplId" : "aeiou",
    "components" : [ {
      "name" : "aeiou",
      "description" : "aeiou",
      "_id" : "aeiou",
      "type" : "aeiou"
    } ],
    "name" : "aeiou",
    "_id" : "aeiou"
  } ],
  "application" : "aeiou",
  "appId" : "aeiou",
  "name" : "aeiou",
  "description" : "aeiou",
  "_id" : "aeiou",
  "kpis" : [ {
    "unit" : "aeiou",
    "level" : "aeiou",
    "metric" : {
      "submetric" : "",
      "unit" : "aeiou",
      "kpi" : "aeiou",
      "name" : "aeiou",
      "description" : "aeiou",
      "_id" : "aeiou",
      "type" : "aeiou",
      "properties" : {
        "key" : "aeiou"
      }
    },
    "name" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou"
  } ],
  "events" : [ {
    "name" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou"
  } ]
};
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.experimentGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expid (String)
   **/

var examples = {};
  
  examples['application/json'] = {
  "deployments" : [ {
    "deplId" : "aeiou",
    "components" : [ {
      "name" : "aeiou",
      "description" : "aeiou",
      "_id" : "aeiou",
      "type" : "aeiou"
    } ],
    "name" : "aeiou",
    "_id" : "aeiou"
  } ],
  "application" : "aeiou",
  "appId" : "aeiou",
  "name" : "aeiou",
  "description" : "aeiou",
  "_id" : "aeiou",
  "kpis" : [ {
    "unit" : "aeiou",
    "level" : "aeiou",
    "metric" : {
      "submetric" : "",
      "unit" : "aeiou",
      "kpi" : "aeiou",
      "name" : "aeiou",
      "description" : "aeiou",
      "_id" : "aeiou",
      "type" : "aeiou",
      "properties" : {
        "key" : "aeiou"
      }
    },
    "name" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou"
  } ],
  "events" : [ {
    "name" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou"
  } ]
};
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.eventGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expid (String)
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "name" : "aeiou",
  "description" : "aeiou",
  "_id" : "aeiou"
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.experimentKPISGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expid (String)
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "unit" : "aeiou",
  "level" : "aeiou",
  "metric" : {
    "submetric" : "",
    "unit" : "aeiou",
    "kpi" : "aeiou",
    "name" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "type" : "aeiou",
    "properties" : {
      "key" : "aeiou"
    }
  },
  "name" : "aeiou",
  "description" : "aeiou",
  "_id" : "aeiou"
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.eventKPIGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expid (String)
   * level (String)
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "unit" : "aeiou",
  "level" : "aeiou",
  "metric" : {
    "submetric" : "",
    "unit" : "aeiou",
    "kpi" : "aeiou",
    "name" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "type" : "aeiou",
    "properties" : {
      "key" : "aeiou"
    }
  },
  "name" : "aeiou",
  "description" : "aeiou",
  "_id" : "aeiou"
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.experimentSnapshotGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expid (String)
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "deplId" : "aeiou",
  "date" : "2016-10-11T14:11:09.893+0000",
  "measures" : [ {
    "refersTo" : [ {
      "reference" : "aeiou",
      "name" : "aeiou",
      "category" : "aeiou"
    } ],
    "level" : "aeiou",
    "kpi" : "aeiou",
    "metric" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "value" : "aeiou"
  } ],
  "name" : "aeiou",
  "deplName" : "aeiou",
  "description" : "aeiou",
  "experimentId" : "aeiou",
  "_id" : "aeiou",
  "vms" : [ {
    "vmId" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "events" : [ "aeiou" ]
  } ]
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.snapshotsGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "deplId" : "aeiou",
  "date" : "2016-10-11T14:11:09.899+0000",
  "measures" : [ {
    "refersTo" : [ {
      "reference" : "aeiou",
      "name" : "aeiou",
      "category" : "aeiou"
    } ],
    "level" : "aeiou",
    "kpi" : "aeiou",
    "metric" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "value" : "aeiou"
  } ],
  "name" : "aeiou",
  "deplName" : "aeiou",
  "description" : "aeiou",
  "experimentId" : "aeiou",
  "_id" : "aeiou",
  "vms" : [ {
    "vmId" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "events" : [ "aeiou" ]
  } ]
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.snapshotsPost = function(args, res, next) {
  /**
   * parameters expected in the args:
   * body (Snapshot)
   **/

var examples = {};
  
  examples['application/json'] = {
  "deplId" : "aeiou",
  "date" : "2016-10-11T14:11:09.900+0000",
  "measures" : [ {
    "refersTo" : [ {
      "reference" : "aeiou",
      "name" : "aeiou",
      "category" : "aeiou"
    } ],
    "level" : "aeiou",
    "kpi" : "aeiou",
    "metric" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "value" : "aeiou"
  } ],
  "name" : "aeiou",
  "deplName" : "aeiou",
  "description" : "aeiou",
  "experimentId" : "aeiou",
  "_id" : "aeiou",
  "vms" : [ {
    "vmId" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "events" : [ "aeiou" ]
  } ]
};
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.snapshotLabelGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snaplabel (String)
   **/

var examples = {};
  
  examples['application/json'] = {
  "deplId" : "aeiou",
  "date" : "2016-10-11T14:11:09.901+0000",
  "measures" : [ {
    "refersTo" : [ {
      "reference" : "aeiou",
      "name" : "aeiou",
      "category" : "aeiou"
    } ],
    "level" : "aeiou",
    "kpi" : "aeiou",
    "metric" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "value" : "aeiou"
  } ],
  "name" : "aeiou",
  "deplName" : "aeiou",
  "description" : "aeiou",
  "experimentId" : "aeiou",
  "_id" : "aeiou",
  "vms" : [ {
    "vmId" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "events" : [ "aeiou" ]
  } ]
};
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.snapshotGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/

var examples = {};
  
  examples['application/json'] = {
  "deplId" : "aeiou",
  "date" : "2016-10-11T14:11:09.903+0000",
  "measures" : [ {
    "refersTo" : [ {
      "reference" : "aeiou",
      "name" : "aeiou",
      "category" : "aeiou"
    } ],
    "level" : "aeiou",
    "kpi" : "aeiou",
    "metric" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "value" : "aeiou"
  } ],
  "name" : "aeiou",
  "deplName" : "aeiou",
  "description" : "aeiou",
  "experimentId" : "aeiou",
  "_id" : "aeiou",
  "vms" : [ {
    "vmId" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "events" : [ "aeiou" ]
  } ]
};
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.snapshotDelete = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/

var examples = {};
  

  
  res.end();
}
exports.deploymentKpis = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "name" : "aeiou",
  "value" : "aeiou"
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.snapshotMeasureByEventGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "measures" : [ {
    "refersTo" : [ {
      "reference" : "aeiou",
      "name" : "aeiou",
      "category" : "aeiou"
    } ],
    "level" : "aeiou",
    "kpi" : "aeiou",
    "metric" : "aeiou",
    "description" : "aeiou",
    "_id" : "aeiou",
    "value" : "aeiou"
  } ],
  "name" : "aeiou",
  "description" : "aeiou",
  "_id" : "aeiou"
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.snapshotMeasuresGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "refersTo" : [ {
    "reference" : "aeiou",
    "name" : "aeiou",
    "category" : "aeiou"
  } ],
  "level" : "aeiou",
  "kpi" : "aeiou",
  "metric" : "aeiou",
  "description" : "aeiou",
  "_id" : "aeiou",
  "value" : "aeiou"
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
exports.snapshotMeasuresPost = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   * body (Measure)
   **/

var examples = {};
  

  
  res.end();
}
exports.snapshotVMsGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/

var examples = {};
  
  examples['application/json'] = [ {
  "vmId" : "aeiou",
  "description" : "aeiou",
  "_id" : "aeiou",
  "events" : [ "aeiou" ]
} ];
  

  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}
