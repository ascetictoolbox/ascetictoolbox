'use strict';
var util = require('util');
var mongoose = require('mongoose'),
	colors = require('colors'),
	config = require('../config'),
	ObjectId = require('mongoose').Types.ObjectId,
	db = mongoose.connection;

db.on('error', function() {
	console.log('Database connection error'.red);
});
db.on('connecting', function () {
	console.log('Database connecting'.cyan);
});
db.once('open', function() {
	console.log('Database connection established'.green);
});
db.on('reconnected', function () {
	console.log('Database reconnected'.green);
});

mongoose.connect(config.db_url, {server: {auto_reconnect: true}});

var experiments = db.collection('experiments');
var snapshots = db.collection('snapshots');

var Models = require('../models/Models.js');

exports.experimentsGet = function(args, res, next) {
  /**
   * parameters expected in the args:
  **/

  experiments.find({}).toArray(function(err,data){
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(data));
  });
}
exports.experimentsPost = function(args, res, next) {
  /**
   * parameters expected in the args:
  * body (Experiment)
  **/
	console.log(util.inspect(args.body.value,false,null));

	experiments.insert(args.body.value,function (err) {
      if (err) throw err;
      experiments.findOne({_id: args.body.value._id},function (err, data) {
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify(data));
      });
    });
}
exports.experimentGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expid (String)
   **/

	 experiments.findOne({_id: new ObjectId(args.expid.value)},function(err,data){
		res.setHeader('Content-Type', 'application/json');
		if(data){
			res.end(JSON.stringify(data));
		}
		else{
			res.statusCode =404;
			res.end();
		}
	 });
}
exports.eventGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expid (String)
   **/
   experiments.find({_id: new ObjectId(args.expid.value)}).toArray(function(err,data){
	 	res.setHeader('Content-Type', 'application/json');
	 	res.end(JSON.stringify(data[0].events));
	 });
}
exports.experimentSnapshotGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expid (String)
   **/
   console.log(args.expId)

   snapshots.find({experimentId: args.expid.value}).toArray(function(err,data){
     res.setHeader('Content-Type', 'application/json');
     res.end(JSON.stringify(data));
   });
}
exports.snapshotsGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expId (String)
  **/
  console.log(args.expId)
	snapshots.find({}).toArray(function(err,data){
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(data));
  });
}

exports.snapshotsPost = function(args, res, next) {
  console.log(util.inspect(args.body.value,false,null));

	snapshots.findOne({name: args.body.value.name},function(err,data){
		console.log(JSON.stringify(data));
		if(data==null){
			snapshots.insert(args.body.value,function (err) {
		      if (err) throw err;
		      snapshots.findOne({name: args.body.value.name}, function (err, data) {
		        res.setHeader('Content-Type', 'application/json');
		        res.end(JSON.stringify(data));
		      });
		    });
		}
		else{
			res.statusCode =412;
			res.end();
		}
	});
}
exports.snapshotGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/

	snapshots.findOne({_id: new ObjectId(args.snapid.value)},function(err,data){
		res.setHeader('Content-Type', 'application/json');
			if(data){
				res.end(JSON.stringify(data));
			}
			else{
				res.statusCode = 404;
				res.end();
			}
	});
}

exports.snapshotMeasuresGet = function(args, res, next) {
   /**
    * parameters expected in the args:
    * snapid (String)
    **/

 	 snapshots.findOne({_id: new ObjectId(args.snapid.value)},function(err,data){
 		 res.setHeader('Content-Type', 'application/json');
 		 res.end(JSON.stringify(data.measures));
 	 });
}
exports.snapshotVMsGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/
   snapshots.find({_id: new ObjectId(args.snapid.value)},function(err,data){
     res.setHeader('Content-Type', 'application/json');
     res.end(JSON.stringify(data[0].vms));
   });
}

exports.experimentKPISGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * expid (String)
   **/
 	experiments.findOne({_id: new ObjectId(args.expid.value)},function(err,data){
 	 res.setHeader('Content-Type', 'application/json');
 	 res.end(JSON.stringify(data.kpis));
 	});
}


exports.deploymentKpis = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/

	snapshots.findOne({_id: new ObjectId(args.snapid.value)},function(err,snap){
		experiments.findOne({_id: new ObjectId(snap.experimentId)},function(err,exp){
			res.setHeader('Content-Type', 'application/json');
			if(snap!=null){
				res.end(JSON.stringify(
					snap.measures
						.filter(function(measure) {
							return measure.level=="deployment";
						})
						.map(function(measure) {
							var units = exp.kpis.filter(function(kpi){return kpi.name==measure.kpi;}).map(function(kpi){return kpi.metric.unit;});
							if(units.length!=0){
								return {name:measure.metric,value:measure.value,unit:units[0]};
							}
							else{
								return {name:measure.metric,value:measure.value,unit:"undefined"};
							}
						})
				));
			}
			else{
				res.statusCode =404;
				res.end();
			}
		});
	});

}


exports.snapshotMeasureByEventGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   **/

	snapshots.findOne({_id: new ObjectId(args.snapid.value)},function(err,snapshot){
		experiments.findOne({_id: new ObjectId(snapshot.experimentId)},function(err,experiment){
			var results = experiment.events.map(function(event){
				var newEvent = Object()
				newEvent._id = event._id
				newEvent.name= event.name
				newEvent.description = event.description
				newEvent.measures = snapshot.measures.filter(function(m){
					var units = experiment.kpis.filter(function(kpi){return kpi.name==m.kpi;}).map(function(kpi){return kpi.metric.unit;});
					if(units.length!=0){m.unit=units[0];}
					else{m.unit="undefined"}
					return m.refersTo.length == 1 && m.refersTo[0].name == event.name
				});
				return newEvent
			});

	 		res.setHeader('Content-Type', 'application/json');
	 		res.end(JSON.stringify(results));
	 	});
	});
	/*
	what to return a cross join between event of the experiment and measure
	*/
}

exports.snapshotLabelGet = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snaplabel (String)
   **/

	snapshots.findOne({name: args.snaplabel.value},function(err,data){
		res.setHeader('Content-Type', 'application/json');
		if(data){
			res.end(JSON.stringify(data));
		}
		else{
			res.statusCode =404;
			res.end();
		}
	});


}


exports.snapshotMeasuresPost = function(args, res, next) {
  /**
   * parameters expected in the args:
   * snapid (String)
   * body (Measure)
   **/


	snapshots.update({_id: new ObjectId(args.snapid.value)},{$addToSet: { "measures" : args.body.value}},function(err,data){
		res.end();
	});



}
